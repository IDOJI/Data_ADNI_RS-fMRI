################################################################################
# Check Voxelwise coordinates
################################################################################
Clipboard_to_path()
path_Extracted_Results = "D:/Data___Backup/Papers___Data/ADNI___RS.fMRI___BOLD.Signals/Voxelwise___AAL3___FunImgARCWSF___Coordinates"
RS.fMRI_5_BOLD.Signals___Voxelwise___Check.Coordinates.Results(path_Extracted_Results)


path_Extracted_Results = "D:/Data___Backup/Papers___Data/ADNI___RS.fMRI___BOLD.Signals/Voxelwise___AAL3___FunImgARglobalCWSF___Coordinates"
RS.fMRI_5_BOLD.Signals___Voxelwise___Check.Coordinates.Results(path_Extracted_Results)