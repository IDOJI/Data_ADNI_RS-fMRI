path_Coordinates = "/Users/Ido/Library/CloudStorage/Dropbox/Github/Rpkgs/ADNIprep/Others/RID_0021___BOLD.Signals___Voxelwise___AAL3___FunImgARCWSF___Coordinates.rds"
path_Export
Simulation_Data = RS.fMRI_6_Generate.Simulation.Data(path_Coordinates, path_Export)
