################################################################################
# Checking All zero timepoints
################################################################################
Clipboard_to_path()



path_Sub.Folders = "D:/ADNI/ADNI_RS.fMRI___SB/AutoMasks_O___MNI_EPI_AAL3___GE.MEDICAL.SYSTEMS"
path_Having_Zero_Timepoints = RS.fMRI_4_Check___Zero.Timepoints___Sub.Folders(path_Sub.Folders, ROI_Signals_Folder = "ROISignals_FunImgARCWSF")


path_Sub.Folders = "D:/ADNI/ADNI_RS.fMRI___SB/AutoMasks_O___MNI_EPI_AAL3___Philips"
path_Having_Zero_Timepoints = RS.fMRI_4_Check___Zero.Timepoints___Sub.Folders(path_Sub.Folders, ROI_Signals_Folder = "ROISignals_FunImgARCWSF")


path_Sub.Folders = "D:/ADNI/ADNI_RS.fMRI___SB/AutoMasks_X___MNI_EPI_AAL3___Philips"
path_Having_Zero_Timepoints = RS.fMRI_4_Check___Zero.Timepoints___Sub.Folders(path_Sub.Folders, ROI_Signals_Folder = "ROISignals_FunImgARCWSF")


path_Sub.Folders = "D:/ADNI/ADNI_RS.fMRI___SB/AutoMasks_O___MNI_EPI_AAL3___SIEMENS"
path_Having_Zero_Timepoints = RS.fMRI_4_Check___Zero.Timepoints___Sub.Folders(path_Sub.Folders, ROI_Signals_Folder = "ROISignals_FunImgARCWSF")


path_Sub.Folders = "F:/AutoMasks_O___MNI_EPI_AAL3___SIEMENS"
path_Having_Zero_Timepoints = RS.fMRI_4_Check___Zero.Timepoints___Sub.Folders(path_Sub.Folders, ROI_Signals_Folder = "ROISignals_FunImgARCWSF")
